import React from 'react'

const Loading = () => {
  return (
    <div>Loading topics....</div>
  )
}

export default Loading