import React from 'react'

const Loading = () => {
  return (
    <div>Data is Loading...</div>
  )
}

export default Loading