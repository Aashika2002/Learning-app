import React from "react";

const Loading = () => {
    return (
        <div>
            <h1 className="text-center my-10">Loading...</h1>
        </div>
    );
};

export default Loading;
